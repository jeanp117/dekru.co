import "./styles.css";
import "./tailwind.css";
import { Image1080 } from "./Image1080";

export default function App() {
return (
    <div>
    <Image1080 />
    </div>
);
}
