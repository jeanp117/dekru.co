/* Code generated with AutoHTML Plugin for Figma */
import "./Image1080.css";

export interface IImage1080Props {}

export const Image1080 = ({ ...props }: IImage1080Props): JSX.Element => {
  return <img className="w-[462px] h-[325px] relative" src="image-1080.png" />;
};
