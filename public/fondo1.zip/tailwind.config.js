module.exports = 
   {
      content: ["./src/**/*.{html,vue,js}"],
      theme: {
        extend: {
          colors: {
            
          },
        }
      }
    }

            